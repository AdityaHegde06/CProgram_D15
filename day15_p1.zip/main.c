/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

//determine whether it year is lear or not

#include<stdio.h>
//function prototype
void leapyear(int);

int main()
{
    int year;
    printf("\n enter year:");
    scanf("%d",&year);
    //calling the function
    leapyear(year);
    return 0;
}
void leapyear(int year)
{
    if(year%4==0&&year%100!=0||year%400==0)
    printf("%d is leap year\n",year);
    else
    printf("%d is not leap year\n",year);
}