/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//obtain prime factors
#include<stdio.h>
//function prototypeint 
void prime(int);

int main()
{
    int num;
    printf("\n enter number:");
    scanf("%d",&num);
    //calling the function
    prime(num);
    return 0;
}
void prime(int num)
{
    int i=2;
    printf("Prime factors of %d are\n",num);
    while(num!=1)
    {
     if(num%i==0)
     printf("%d",i);
     else
     {
         i++;
         continue;
     }
     num=num/i;
     }
}